package ljwao94.c.board;

public class Main {

	public static void main(String[] args) {
		Board board = new Board();
		board.run();
	}
}
//삭제기능이 추가된 와인게시판 v0.0.0
//수정기능이 추가될 예정  v0.0.1