package ljwao94.c.board;

import ljwao94.c.board.data.Data;
import ljwao94.c.board.data.Post;
import ljwao94.util.Cw;

public class WineMenuList {
	static void run() {
		Cw.wn("====================");
		Cw.wn("와인 리스트");
		Cw.wn("====================");
		for (Post p : Data.posts) {
			p.infoForList();
			Cw.wn("====================");
		}
	}
}