 package ljwao94.c.board.display;

import ljwao94.c.board.Board;
import ljwao94.util.Cw;

public class Disp {
	public static void title() {
		Cw.line();
		Cw.dot();
		Cw.space(10);
		Cw.w(Board.TITLE);
		Cw.space(10);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}
	public static void menuMain() {
		Cw.dot();
		Cw.w("[1.와인 리스트 | 2.검색 | 3.글작성 | 4.글 삭제 | e.종료]");
		Cw.dot();
		Cw.wn();
	}

}