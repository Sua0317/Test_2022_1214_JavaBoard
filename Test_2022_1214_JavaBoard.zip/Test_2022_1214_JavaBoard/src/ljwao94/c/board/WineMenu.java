package ljwao94.c.board;

import ljwao94.c.board.display.Disp;
import ljwao94.util.Ci;
import ljwao94.util.Cw;

public class WineMenu {
	static void run() {
		Disp.menuMain();
		loop: while (true) {
			String cmd = Ci.r("입력창");
			switch (cmd) {
			case "1":
				WineMenuList.run();
				break;
			case "2":
				WineMenuRead.run();
				break;
			case "3":
				WineMenuWrite.run();
				break;
			case "4":
				WineMenuDel.run();
				break;
			case "e":
				System.out.println("프로그램 종료");
				break loop;
			default:
				Cw.wn("항목에 없는 사항입니다.");
				break;
			}
		}
	}
}
