package ljwao94.c.board;

import ljwao94.c.board.data.Data;
import ljwao94.util.Ci;
import ljwao94.util.Cw;

public class WineMenuDel {
	static void run() {
		Cw.wn("====================");
		Cw.wn("삭제하기");
		Cw.wn("====================");
		String cmd = Ci.r("삭제할 글번호 입력");
		// 삭제할 글 찾기(바로 삭제하지 말고)*
		// 바로삭제시 문제생길수 있음
		int tempSearchIndex = 0;
		for (int i = 0; i < Data.posts.size(); i = i + 1) {
			if (cmd.equals(Data.posts.get(i).instanceNo + "")) {
				tempSearchIndex = i;
			}
		}
		Data.posts.remove(tempSearchIndex);
		Cw.wn("글 수:" + Data.posts.size());
	}
}
