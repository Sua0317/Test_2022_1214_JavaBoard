package ljwao94.c.board;

import ljwao94.c.board.data.Data;
import ljwao94.c.board.data.Post;
import ljwao94.util.Ci;
import ljwao94.util.Cw;

public class WineMenuWrite {
	static void run() {
		Cw.wn("====================");
		Cw.wn("입력 쓰기");
		String title;
		while (true) {
			Cw.wn("====================");
			title = Ci.rl("와인 이름");
			if (title.length() > 0) {
				break;
			} else {
				Cw.wn("====================");
				Cw.wn("항목에 없는 사항입니다.");
			}
		}
		String content;
		while (true) {
			Cw.wn("====================");
			content = Ci.rl("와인 품종");
			if (content.length() > 0) {
				break;
			} else {
				Cw.wn("====================");
				Cw.wn("항목에 없는 사항입니다.");
			}
		}
		String country;
		while (true) {
			Cw.wn("====================");
			country = Ci.rl("와인 생산지");
			if (country.length() > 0) {
				break;
			} else {
				Cw.wn("====================");
				Cw.wn("항목에 없는 사항입니다.");
			}
		}
		String taste;
		while (true) {
			Cw.wn("====================");
			taste = Ci.rl("와인 테이스팅");
			if (taste.length() > 0) {
				break;
			} else {
				Cw.wn("====================");
				Cw.wn("항목에 없는 사항입니다.");
			}
		}
		String writer;
		while (true) {
			Cw.wn("====================");
			writer = Ci.r("작성자");
			if (writer.length() > 0) {
				break;
			} else {
				Cw.wn("====================");
				Cw.wn("항목에 없는 사항입니다.");
			}
		}

		Post p = new Post(title, content, country, taste, writer, 0);
		Data.posts.add(p);
		Cw.wn("====================");
		Cw.wn("글작성 완료");
		Cw.wn("====================");
	}
}
