package ljwao94.c.board.data;

import java.time.LocalDate;

import ljwao94.util.Cw;

public class Post {
	static public int no = 0;
	public int instanceNo = 0;
	public String Title;        //와인이름              
	public String Content;      //와인품종
	public String Country;      //와인생산지 지역 및 나라
	public String taste;        //와인 당도 산도 바디감 측정
	public String Writer;       //작성자
	public int Hit;             //조회수
	public String Date;         //업로드날짜

	public Post(String Title, String Content, String country, String taste, String Writer, int Hit) {
		no = no + 1;
		instanceNo = no;
		this.Title = Title;
		this.Content = Content;
		this.Country = country;
		this.taste = taste;
		this.Writer = Writer;
		this.Hit = Hit;
		LocalDate now = LocalDate.now();
		Date = now.toString();
	}

	public void infoForList() {
		Cw.wn(" 페이지:" + instanceNo);
		Cw.wn(" 와인 이름:" + Title);
		Cw.wn(" 작성자:" + Writer);
		Cw.wn(" 조회수:" + Hit);
		Cw.wn(" 업로드날짜:" + Date);
	}

	public void infoForRead() {
		Cw.wn(" 와인 이름:" + Title);
		Cw.wn(" 품종:" + Content);
		Cw.wn(" 생산지:" + Country);
		Cw.wn(" 테이스팅노트:" + taste);
		Cw.wn(" 작성자:" + Writer);
		Cw.wn(" 조회수:" + Hit);
		Cw.wn(" 업로드날짜:" + Date);
	}
}
