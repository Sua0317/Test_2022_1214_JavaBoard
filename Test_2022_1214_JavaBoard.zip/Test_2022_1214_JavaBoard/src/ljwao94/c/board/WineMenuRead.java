package ljwao94.c.board;

import ljwao94.c.board.data.Data;
import ljwao94.c.board.data.Post;
import ljwao94.util.Ci;
import ljwao94.util.Cw;

public class WineMenuRead {
	static void run() {
		Cw.wn("====================");
		Cw.wn("자세항 정보 읽기");
		String cmd = Ci.r("읽을 글 번호");
		Cw.wn("====================");
		for (Post p : Data.posts) {
			if (cmd.equals(p.instanceNo + "")) {
				p.infoForRead();
				Cw.wn("====================");
			}
		}
	}
}