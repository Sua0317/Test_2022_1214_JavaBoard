package ljwao94.c.board;

import ljwao94.c.board.data.Data;
import ljwao94.c.board.display.Disp;

public class Board {
	public static final String VERSION = "v0.0.0";
	public static final String TITLE = "와인에 대한 모든것 (" + VERSION + ")feat. Lee";

	public void run() {
		Data.loadData();
		Disp.title();
		WineMenu.run();
	}
}
